# Informe de recuperación técnica — Partituras-10B.apk

## Evidencia observada directamente en la APK

- Paquete identificado en las referencias DEX: `com.pepe.partituras`.
- La APK contiene varios DEX (`classes.dex` y DEX adicionales); el código de la aplicación aparece principalmente en `classes5.dex`, `classes6.dex` y `classes7.dex`.
- Referencias Kotlin identificadas mediante cadenas y metadatos de depuración: `BibliotecaScreenKt`, `LectorScreenKt`, `MetronomoScreenKt`, `AfinadorScreenKt` y `PartituraEntity` / `TrazoEntity`.
- Hay una instrucción SQL de Room para la tabla `partituras` con campos `id`, `titulo`, `compositor`, `archivoInterno`, `paginas`, `favorita`, `setlist`, `ultimaPagina` y `fechaAgregada`.
- Se encontraron referencias a `android.graphics.pdf.PdfRenderer`.
- También aparecen referencias a `CancionEntity` y consultas de Room relacionadas con `setlist`.

## Límites de la recuperación

No se han recuperado archivos `.kt` originales directamente desde la APK. Los nombres de clases y líneas de depuración permiten orientar una decompilación, pero no sustituyen el código fuente. En este entorno no se ha encontrado instalado `jadx`, `apktool` ni Gradle, por lo que no se ha podido ejecutar una decompilación completa ni compilar/verificar la aplicación reconstruida.

## Base de reconstrucción incluida

La carpeta Android Studio incluye una implementación independiente con:

- Importación y copia privada de PDFs.
- Biblioteca con búsqueda, favoritos y metadatos editables: título, compositor, instrumento, tonalidad, género, colección/setlist y notas personales.
- Lector PDF real mediante `PdfRenderer`, con navegación de páginas.
- Paleta inicial de símbolos musicales; al elegir un símbolo y tocar la página se guarda una anotación normalizada por partitura y página.
- Persistencia local de biblioteca y anotaciones mediante SharedPreferences/JSON.

Esta implementación es una reconstrucción funcional inicial, no una recuperación exacta de las pantallas originales. El metrónomo, afinador, setlists avanzados y la migración de la base Room original aún necesitan implementarse/integrarse. No se ha afirmado que la compilación haya sido probada.

## Cómo continuar

1. Abrir `PartiturasRecovery` desde Android Studio con JDK 17 y Android SDK instalado.
2. Sincronizar Gradle y resolver cualquier incompatibilidad de plugins/SDK que señale el IDE.
3. Compilar y probar importación, renderizado PDF, navegación, edición de campos y persistencia de símbolos.
4. En una fase posterior, instalar `jadx` en un entorno de desarrollo y decompilar la APK para comparar la lógica original con esta base; no sobrescribir ni borrar la app original hasta validar la nueva.
