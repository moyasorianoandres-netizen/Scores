# Investigación de proyectos open source para mejorar Partituras Recovery

Fecha: 2026-10-11

Esta investigación no afirma haber encontrado literalmente todos los proyectos existentes; revisa los proyectos públicos más relevantes localizados para un lector de partituras Android y compara sus funciones. Antes de copiar código o dependencias hay que verificar la licencia y su compatibilidad con la distribución prevista.

## Proyectos revisados

### 1. Sheetopia — https://github.com/juho05/sheetopia
- App multiplataforma local-first, incluido Android.
- Importación de PDF, metadatos (título, compositor, instrumentos, géneros, etiquetas, fuente y notas), búsqueda/filtros, modo lectura a pantalla completa, anotaciones con stylus, setlists, pedales USB/Bluetooth, controladores MIDI, importación/exportación y tema claro/oscuro.
- Valor para nuestro proyecto: lista de funciones de biblioteca y lectura que conviene priorizar.
- Acción recomendada: estudiar arquitectura y comportamiento; no copiar archivos sin revisar LICENSE y dependencias.

### 2. ExCoda — https://github.com/appexcoda/excoda
- Lector Android centrado en tabletas; PDF y tablaturas/MusicXML mediante AlphaTab.
- Anotación a mano alzada, resaltador, herramientas de selección/borrado, doble página en horizontal, gestos de navegación, controles ocultables y sincronización SMB opcional.
- Valor para nuestro proyecto: ideas para modo concierto, doble página y anotaciones más robustas.
- Acción recomendada: reutilización solo después de revisar licencia, estructura y compatibilidad de componentes.

### 3. FOSScore — https://github.com/musigatto/FOSScore
- Proyecto Android Kotlin + Jetpack Compose + Material 3, pensado como lector libre.
- Plan de funciones: PDF con MuPDF, metadatos, setlists, anotaciones con sellos musicales/capas/stylus, pistas de audio, metrónomo, afinador, MIDI, marcadores y gestión de páginas.
- Estado: el README revisado marca las funciones principales como pendientes; no debe considerarse una implementación madura sin inspeccionar el código.
- Licencia declarada: AGPL-3.0. El README también advierte que MuPDF es AGPL y puede imponer obligaciones de publicación de fuente para una obra combinada; confirmar la licencia exacta de cada versión y obtener asesoramiento antes de distribuir.
- Valor para nuestro proyecto: lista de funcionalidades y referencia de arquitectura, no dependencia que debamos añadir automáticamente.

### 4. DoReMidi — https://github.com/Zimbelstern/DoReMidi
- Lector PDF Android basado en MuPDF con cambio de página mediante dispositivos MIDI.
- Licencia indicada en su README: AGPL-3.0.
- Valor para nuestro proyecto: posible referencia para pedales MIDI, sujeto a revisión de licencia.

## Decisiones para Partituras Recovery

1. Mantener por ahora Kotlin + Jetpack Compose + Android `PdfRenderer`, evitando añadir MuPDF/AlphaTab hasta decidir las obligaciones de licencia y confirmar la necesidad técnica.
2. Conservar el PDF original y guardar las anotaciones como una capa de datos separada, por página, en coordenadas normalizadas.
3. Mejorar el modelo de anotación: `id`, tipo (sello/texto/trazo/resaltador), símbolo, posición, escala, rotación, color y orden; añadir mover/borrar/deshacer.
4. Mejorar el modelo de partitura con título, compositor, instrumento, tonalidad, género, etiquetas, colección/setlist, notas, favorito, última página y URI/archivo gestionado.
5. Mejorar lectura: pantalla completa, ajuste a página/ancho, gesto de página, persistencia de última página, mantener pantalla encendida y controles grandes.
6. Añadir pruebas para importar PDF, abrir y cambiar páginas, guardar/cargar anotaciones y editar metadatos.
7. No afirmar que la APK está compilada hasta ejecutar `./gradlew assembleDebug` con JDK y Android SDK adecuados y comprobar el artefacto.

## Fuentes consultadas

- https://github.com/juho05/sheetopia (README.md)
- https://github.com/appexcoda/excoda (README.md)
- https://github.com/musigatto/FOSScore (README.md)
- https://github.com/Zimbelstern/DoReMidi

La búsqueda no es exhaustiva; el ecosistema cambia y el estado/licencia deben volver a comprobarse antes de incorporar código.
