package com.pepe.partituras

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1C2933)
private val Accent = Color(0xFF68D4C5)
private val Paper = Color(0xFFF7F4ED)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Ink, surface = Panel)) { RecoveryHome(this) } }
    }
}

data class ScoreItem(
    val id: String, val title: String, val composer: String, val fileName: String,
    val lastPage: Int = 0, val favorite: Boolean = false, val instrument: String = "",
    val key: String = "", val genre: String = "", val collection: String = "", val notes: String = ""
)
data class Stamp(val x: Float, val y: Float, val symbol: String)

private fun loadScores(context: Context): MutableList<ScoreItem> {
    val raw = context.getSharedPreferences("recovery", Context.MODE_PRIVATE).getString("scores", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        MutableList(arr.length()) { i -> arr.getJSONObject(i).let {
            ScoreItem(it.optString("id"), it.optString("title"), it.optString("composer"), it.optString("fileName"), it.optInt("lastPage"), it.optBoolean("favorite"), it.optString("instrument"), it.optString("key"), it.optString("genre"), it.optString("collection"), it.optString("notes"))
        } }
    } catch (_: Exception) { mutableListOf() }
}
private fun saveScores(context: Context, scores: List<ScoreItem>) {
    val arr = JSONArray()
    scores.forEach { s -> arr.put(JSONObject().put("id", s.id).put("title", s.title).put("composer", s.composer).put("fileName", s.fileName).put("lastPage", s.lastPage).put("favorite", s.favorite).put("instrument", s.instrument).put("key", s.key).put("genre", s.genre).put("collection", s.collection).put("notes", s.notes)) }
    context.getSharedPreferences("recovery", Context.MODE_PRIVATE).edit().putString("scores", arr.toString()).apply()
}
private fun stampPrefs(context: Context) = context.getSharedPreferences("score_stamps", Context.MODE_PRIVATE)
private fun loadStamps(context: Context, scoreId: String, page: Int): List<Stamp> = try {
    val arr = JSONArray(stampPrefs(context).getString("$scoreId:$page", "[]") ?: "[]")
    List(arr.length()) { i -> arr.getJSONObject(i).let { Stamp(it.getDouble("x").toFloat(), it.getDouble("y").toFloat(), it.getString("symbol")) } }
} catch (_: Exception) { emptyList() }
private fun saveStamps(context: Context, scoreId: String, page: Int, stamps: List<Stamp>) {
    val arr = JSONArray(); stamps.forEach { arr.put(JSONObject().put("x", it.x).put("y", it.y).put("symbol", it.symbol)) }
    stampPrefs(context).edit().putString("$scoreId:$page", arr.toString()).apply()
}
private suspend fun renderPage(context: Context, fileName: String, pageIndex: Int): Pair<Bitmap?, Int> = withContext(Dispatchers.IO) {
    val file = File(context.filesDir, fileName)
    if (!file.exists()) return@withContext null to 0
    var descriptor: ParcelFileDescriptor? = null
    var renderer: PdfRenderer? = null
    try {
        descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        renderer = PdfRenderer(descriptor)
        val count = renderer.pageCount
        if (count == 0) return@withContext null to 0
        val idx = pageIndex.coerceIn(0, count - 1)
        renderer.openPage(idx).use { page ->
            val width = 1400
            val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bitmap to count
        }
    } catch (_: Exception) { null to 0 }
    finally { try { renderer?.close() } catch (_: Exception) {}; try { descriptor?.close() } catch (_: Exception) {} }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecoveryHome(context: Context) {
    val scores = remember { mutableStateListOf<ScoreItem>().also { it.addAll(loadScores(context)) } }
    var search by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<ScoreItem?>(null) }
    var reader by remember { mutableStateOf<ScoreItem?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching {
            val name = "score_${UUID.randomUUID()}.pdf"
            context.contentResolver.openInputStream(uri)!!.use { input -> FileOutputStream(File(context.filesDir, name)).use(input::copyTo) }
            val title = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')?.replace('_', ' ') ?: "Nueva partitura"
            scores.add(ScoreItem(UUID.randomUUID().toString(), title, "", name)); saveScores(context, scores)
        }
    }

    if (editing != null) {
        val item = editing!!
        var title by remember(item.id) { mutableStateOf(item.title) }; var composer by remember(item.id) { mutableStateOf(item.composer) }
        var instrument by remember(item.id) { mutableStateOf(item.instrument) }; var key by remember(item.id) { mutableStateOf(item.key) }
        var genre by remember(item.id) { mutableStateOf(item.genre) }; var collection by remember(item.id) { mutableStateOf(item.collection) }; var notes by remember(item.id) { mutableStateOf(item.notes) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("Editar partitura") },
            text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true)
                    OutlinedTextField(composer, { composer = it }, label = { Text("Compositor") }, singleLine = true)
                    OutlinedTextField(instrument, { instrument = it }, label = { Text("Instrumento") }, singleLine = true)
                    OutlinedTextField(key, { key = it }, label = { Text("Tonalidad") }, singleLine = true)
                    OutlinedTextField(genre, { genre = it }, label = { Text("Género") }, singleLine = true)
                    OutlinedTextField(collection, { collection = it }, label = { Text("Colección / setlist") }, singleLine = true)
                    OutlinedTextField(notes, { notes = it }, label = { Text("Notas personales") }, minLines = 2)
            } }, confirmButton = { TextButton(onClick = {
                val idx = scores.indexOfFirst { it.id == item.id }
                if (idx >= 0) scores[idx] = item.copy(title = title.ifBlank { "Sin título" }, composer = composer, instrument = instrument, key = key, genre = genre, collection = collection, notes = notes)
                saveScores(context, scores); editing = null
            }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancelar") } })
    }

    if (reader != null) ScoreReader(context, reader!!, onClose = { updated ->
        val idx = scores.indexOfFirst { it.id == updated.id }; if (idx >= 0) scores[idx] = updated
        saveScores(context, scores); reader = null
    })

    Scaffold(containerColor = Ink, topBar = { TopAppBar(title = { Column { Text("PARTITURAS", fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("Biblioteca musical · recuperación", fontSize = 12.sp, color = Color.LightGray) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White)) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { picker.launch(arrayOf("application/pdf")) }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Importar PDF") }, containerColor = Accent, contentColor = Ink) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
            OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), placeholder = { Text("Buscar título o compositor") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Mi biblioteca", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("${scores.size} partituras", color = Accent, fontSize = 13.sp) }
            if (scores.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.MusicNote, null, tint = Accent, modifier = Modifier.size(48.dp)); Text("Tu repertorio empieza aquí", fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Importa una partitura PDF para añadirla a tu biblioteca.", color = Color.LightGray) } }
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 100.dp)) {
                items(scores.filter { it.title.contains(search, true) || it.composer.contains(search, true) || it.collection.contains(search, true) || it.instrument.contains(search, true) || it.key.contains(search, true) || it.genre.contains(search, true) || it.notes.contains(search, true) }, key = { it.id }) { score ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { reader = score }.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(52.dp).background(Color(0xFF31434D), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Accent, modifier = Modifier.size(28.dp)) }
                        Column(Modifier.weight(1f)) { Text(score.title, fontWeight = FontWeight.SemiBold, maxLines = 2); Text(score.composer.ifBlank { "Compositor sin especificar" }, color = Color.LightGray, fontSize = 13.sp); Text(listOf(score.instrument, score.key, score.collection).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "PDF local" }, color = Accent, fontSize = 11.sp) }
                        IconButton(onClick = { val idx = scores.indexOfFirst { it.id == score.id }; if (idx >= 0) scores[idx] = score.copy(favorite = !score.favorite); saveScores(context, scores) }) { Icon(if (score.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito", tint = Accent) }
                        IconButton(onClick = { editing = score }) { Icon(Icons.Default.Edit, "Editar metadatos", tint = Accent) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScoreReader(context: Context, initial: ScoreItem, onClose: (ScoreItem) -> Unit) {
    var item by remember(initial.id) { mutableStateOf(initial) }
    var page by remember(initial.id) { mutableIntStateOf(initial.lastPage) }
    var pageCount by remember { mutableIntStateOf(0) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var stamps by remember(initial.id, page) { mutableStateOf(loadStamps(context, initial.id, page)) }
    var selected by remember { mutableStateOf("♯") }
    var showPalette by remember { mutableStateOf(true) }
    var placementMode by remember { mutableStateOf(true) }
    var selectedStampIndex by remember { mutableIntStateOf(-1) }
    var previousStamps by remember(initial.id, page) { mutableStateOf<List<Stamp>?>(null) }
    val symbols = listOf("♯", "♭", "♮", "𝅝", "𝅗𝅥", "𝅘𝅥", "𝅘𝅥𝅮", "𝅘𝅥𝅯", "𝄐", "𝄑", "𝆑", "p", "pp", "mp", "mf", "f", "ff", "♩")
    LaunchedEffect(item.fileName, page) { val result = renderPage(context, item.fileName, page); bitmap = result.first; pageCount = result.second; stamps = loadStamps(context, item.id, page) }
    Column(Modifier.fillMaxSize().background(Color(0xFF080B0D))) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onClose(item.copy(lastPage = page)) }) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White) }
            Column(Modifier.weight(1f)) { Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1); Text("Página ${if (pageCount == 0) 0 else page + 1} / $pageCount", color = Accent, fontSize = 12.sp) }
            TextButton(onClick = { showPalette = !showPalette }) { Text(if (showPalette) "Ocultar" else "Símbolos") }
        }
        if (showPalette) Column(Modifier.fillMaxWidth().background(Color(0xFF182229)).padding(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (placementMode) "Colocar símbolo: toca la partitura" else "Mover símbolo: selecciónalo y toca su destino", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { placementMode = !placementMode; selectedStampIndex = -1 }) { Text(if (placementMode) "Mover" else "Colocar") }
            }
            symbols.chunked(9).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) { row.forEach { symbol -> Surface(color = if (selected == symbol) Accent else Panel, shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f).clickable { selected = symbol }) { Box(Modifier.height(38.dp), contentAlignment = Alignment.Center) { Text(symbol, color = if (selected == symbol) Ink else Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) } } }; repeat(9 - row.size) { Spacer(Modifier.weight(1f)) } } }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                val image = bitmap!!
                Box(Modifier.fillMaxWidth().fillMaxHeight(), contentAlignment = Alignment.Center) {
                    androidx.compose.foundation.Image(image.asImageBitmap(), contentDescription = "Página de la partitura", modifier = Modifier.fillMaxWidth().fillMaxHeight(), contentScale = ContentScale.Fit)
                    Canvas(Modifier.fillMaxSize().pointerInput(selected, page, stamps, placementMode, selectedStampIndex) { detectTapGestures { offset ->
                        val x = (offset.x / size.width).coerceIn(0f, 1f); val y = (offset.y / size.height).coerceIn(0f, 1f)
                        previousStamps = stamps.toList()
                        if (placementMode) {
                            val updated = stamps + Stamp(x, y, selected)
                            stamps = updated
                            saveStamps(context, item.id, page, updated)
                        } else if (selectedStampIndex >= 0 && selectedStampIndex < stamps.size) {
                            val updated = stamps.toMutableList().also { it[selectedStampIndex] = it[selectedStampIndex].copy(x = x, y = y) }
                            stamps = updated
                            saveStamps(context, item.id, page, updated)
                            selectedStampIndex = -1
                        } else {
                            selectedStampIndex = stamps.indices.minByOrNull { i ->
                                val dx = (stamps[i].x - x) * size.width; val dy = (stamps[i].y - y) * size.height
                                dx * dx + dy * dy
                            }?.takeIf { i ->
                                val dx = (stamps[i].x - x) * size.width; val dy = (stamps[i].y - y) * size.height
                                dx * dx + dy * dy < 70f * 70f
                            } ?: -1
                        }
                    } }) {
                        stamps.forEachIndexed { index, stamp ->
                        if (!placementMode && index == selectedStampIndex) drawCircle(Color(0xFF68D4C5), radius = 26f, center = Offset(stamp.x * size.width, stamp.y * size.height), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
                        drawContext.canvas.nativeCanvas.drawText(stamp.symbol, stamp.x * size.width, stamp.y * size.height, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(190, 30, 45); textSize = 42f; textAlign = android.graphics.Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD })
                    }
                    }
                }
            } else Text("No se ha podido abrir el PDF. Comprueba que el archivo se importó correctamente.", color = Color.White)
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { if (page > 0) page-- }, enabled = page > 0) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(4.dp)); Text("Anterior") }
            Text("${if (pageCount == 0) 0 else page + 1} / $pageCount", color = Color.White)
            OutlinedButton(onClick = { if (page < pageCount - 1) page++ }, enabled = page < pageCount - 1) { Text("Siguiente"); Spacer(Modifier.width(4.dp)); Icon(Icons.Default.ArrowForward, null) }
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 2.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { previousStamps?.let { stamps = it; saveStamps(context, item.id, page, it) }; previousStamps = null; selectedStampIndex = -1 }) { Icon(Icons.Default.Undo, null); Spacer(Modifier.width(4.dp)); Text("Deshacer") }
            TextButton(onClick = { if (selectedStampIndex in stamps.indices) { previousStamps = stamps.toList(); val updated = stamps.toMutableList().also { it.removeAt(selectedStampIndex) }; stamps = updated; saveStamps(context, item.id, page, updated); selectedStampIndex = -1 } }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Borrar seleccionado") }
            TextButton(onClick = { previousStamps = stamps.toList(); stamps = emptyList(); selectedStampIndex = -1; saveStamps(context, item.id, page, stamps) }) { Text("Borrar página", color = Color(0xFFFFB4AB)) }
        }
    }
}
