# Partituras Recovery — reconstrucción Android Studio

Esta es una base de reconstrucción independiente basada en las funciones identificadas dentro de `Partituras-10B.apk`. No es el código fuente original ni una APK ya compilada.

## Funciones incluidas en esta versión

- Importar PDF y copiarlo al almacenamiento privado de la app.
- Buscar partituras por título, compositor o colección.
- Editar título, compositor, instrumento, tonalidad, género, colección/setlist y notas personales.
- Marcar partituras como favoritas.
- Leer PDFs mediante `PdfRenderer` y navegar entre páginas.
- Colocar símbolos musicales seleccionados desde una paleta; las posiciones se guardan por partitura y página.
- Borrar los símbolos de la página actual.

## Abrir

1. Descomprime el ZIP.
2. Abre la carpeta `PartiturasRecovery` en Android Studio.
3. Usa JDK 17 y un Android SDK compatible con `compileSdk 35`.
4. Sincroniza Gradle, compila y prueba en un dispositivo/emulador.

## Importante

La compilación no se ha podido verificar en el entorno que preparó estos archivos. Si Android Studio informa errores de sincronización o Kotlin, deben corregirse allí antes de instalar. El metrónomo y afinador originales aún no se han reconstruido. Consulta `RECUPERACION_TECNICA.md` para la evidencia extraída y los límites conocidos.

## Investigación de código abierto

Consulta [OPEN_SOURCE_RESEARCH.md](OPEN_SOURCE_RESEARCH.md) para la comparación de proyectos open source (Sheetopia, ExCoda, FOSScore y DoReMidi), notas de licencia y decisiones propuestas para la evolución del lector.

## Mejoras de esta iteración

- Búsqueda ampliada a instrumento, tonalidad, género y notas personales.
- Formulario de edición con desplazamiento vertical para pantallas pequeñas.
- Modo de colocación y modo de recolocación de símbolos (seleccionar símbolo existente y tocar el destino).
- Deshacer la última modificación de la página, borrar símbolo seleccionado y limpiar la página.
- Workflow de GitHub Actions en `.github/workflows/android-build.yml` para intentar compilar la APK de depuración y publicar el artefacto en cada push/PR y ejecución manual.

### Compilación automatizada

Sube la carpeta del proyecto a un repositorio GitHub y abre la pestaña **Actions**. El workflow ejecuta `assembleDebug` con JDK 17, Android SDK y Gradle, y publica el APK como artefacto si la compilación termina correctamente. Este entorno local no dispone de Gradle/Android SDK, por lo que no se afirma que la compilación ya haya pasado.
