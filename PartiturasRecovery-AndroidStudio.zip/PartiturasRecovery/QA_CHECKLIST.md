# Lista de pruebas manuales

## Biblioteca
- [ ] Importar un PDF válido desde el selector del sistema.
- [ ] Importar un PDF con espacios y acentos en el nombre.
- [ ] Buscar por título, compositor, instrumento, tonalidad, género, colección y notas.
- [ ] Editar metadatos, cerrar y volver a abrir para verificar persistencia.
- [ ] Marcar/desmarcar favorito y reiniciar la app.
- [ ] Probar una biblioteca vacía y una biblioteca con muchas partituras.

## Lector
- [ ] Abrir PDF de una y varias páginas.
- [ ] Navegar anterior/siguiente y volver a la biblioteca.
- [ ] Confirmar que se recuerda la última página.
- [ ] Colocar sostenido, bemol, becuadro y nota musical.
- [ ] Cerrar y reabrir; verificar que los símbolos siguen en la misma página.
- [ ] Cambiar a modo mover, seleccionar un símbolo y recolocarlo.
- [ ] Deshacer, borrar símbolo seleccionado y limpiar página.
- [ ] Probar PDF dañado, PDF vacío y archivo eliminado.
- [ ] Probar móvil pequeño, tableta, retrato y paisaje.

## Compilación
- [ ] GitHub Actions finaliza en verde.
- [ ] Descargar el artefacto APK e instalarlo en Android.
- [ ] Revisar logs de errores y fugas de memoria al abrir PDFs grandes.
